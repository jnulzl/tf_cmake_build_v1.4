//
//  main.m
//  gemmlowp_test
//
//  Created by petewarden on 9/28/15.
//  Copyright (c) 2015 petewarden. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
  @autoreleasepool {
      return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
  }
}
